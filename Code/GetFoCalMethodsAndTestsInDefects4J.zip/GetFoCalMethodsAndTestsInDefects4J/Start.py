import sys
import getopt
import os
import utils.getFoCalMethodsAndTests as getFoCalMethodsAndTests

def main(argv):
    defects4j_path = ""
    output_path = ""
    temp_path = os.path.dirname(os.path.abspath(__file__))
    opts, args = getopt.getopt(argv[1:], "hd:o:t:", ["help", "defects4j_path=","output_path=","temp_path="])
    for opt, arg in opts:
        if opt in ("-h", "--help"):
            print('Start.py -d <defects4j_path> -o <output_path> [-t <temp_path>]')
            print('temp_path will be the current path in default.')
            sys.exit()
        elif opt in ("-d", "--defects4j_path"):
            defects4j_path = arg
        elif opt in ("-o", "--output_path"):
            output_path = arg
        elif opt in ("-t", "--temp_path"):
            temp_path = arg
    if defects4j_path == "":
        print("defects4j_path is needed")
        sys.exit()
    if output_path == "":
        print("output_path is needed")
    getFoCalMethodsAndTests(defects4j_path, output_path, temp_path)

if __name__ == "__main__":
    main(sys.argv)