import os
import re

PATH_SPLITER = '/'

def getSrcCode(defects4j_path, project, trigger_id, project_src_path, is_bug):
    cmd = defects4j_path + PATH_SPLITER + "framework" + PATH_SPLITER + "bin" + PATH_SPLITER + "defects4j checkout -p " + project + " -v " + trigger_id + "b -w " + project_src_path
    if os.system(cmd) == 1:
        if is_bug:
            fail_message = "Error:Fail to get " + project + ":" + trigger_id + "b source code"
        else:
            fail_message = "Error:Fail to get " + project + ":" + trigger_id + "f source code"
        print(fail_message)

def parseTriggerTest(trigger_tests_path):
    with open(trigger_tests_path) as f:
        for line in f.readlines():
            if re.match('.*(Tests.).*(Tests.java:).*', line):
                for token in line.split(' '):
                    if re.match('.*(Tests.).*(Tests.java:).*', token):
                        tmp = token.split('(')
                        folders = tmp[0].split('.')
                        test_function_name = folders[-1]
                        trigger_test_file_path = ''
                        for i in range(len(folders) - 2):
                            trigger_test_file_path = trigger_test_file_path + PATH_SPLITER + folders[i]
                        
                        file_name_and_line = tmp[1].split(':')
                        trigger_test_file_path = trigger_test_file_path + PATH_SPLITER + file_name_and_line[0]
                        target_line = int("".join(filter(str.isdigit, file_name_and_line[1])))
                        return trigger_test_file_path, test_function_name, target_line
    raise Exception('Fail to parse ' + trigger_tests_path)
