import os
import sys
import re
import utils
import findSrcCode as fsc

projects = ("Chart","Cli","Closure","Codec","Collections",
                "Compress","Csv","Gson","JacksonCore","JacksonDatabind"
                ,"JacksonXml","Jsoup","JxPath","Lang","Math",
                "Mockito","Time")

PATH_SPLITER = '/'

def getFoCalMethodsAndTests(defects4j_path, output_path, temp_path):
    projects_path = defects4j_path + PATH_SPLITER + "framework" + PATH_SPLITER + "projects"
    if not os.path.exists(projects_path):
        print("Error: defects4j projects don't exist.")
        sys.exit()
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    if not os.path.exists(temp_path):
        os.mkdir(temp_path)
    for project in projects:
        project_path = projects_path + PATH_SPLITER + project
        triggers_path = project_path + PATH_SPLITER + "trigger_tests"
        for trigger_id in os.listdir(triggers_path):
            project_bug_src_path = temp_path + PATH_SPLITER + project
            project_fix_src_path = temp_path + PATH_SPLITER + project
            utils.getSrcCode(defects4j_path, project, trigger_id, project_bug_src_path, True)
            utils.getSrcCode(defects4j_path, project, trigger_id, project_fix_src_path, False)
            trigger_test_file_path, test_function_name, target_line = utils.parseTriggerTestsFile(triggers_path + PATH_SPLITER + trigger_id)
            trigger_test_file_path = project_bug_src_path + PATH_SPLITER + "tests" + trigger_test_file_path
            fsc.getTriggerTestCode(output_path + PATH_SPLITER + project + PATH_SPLITER + trigger_id + PATH_SPLITER, trigger_test_file_path, test_function_name, target_line)
            
